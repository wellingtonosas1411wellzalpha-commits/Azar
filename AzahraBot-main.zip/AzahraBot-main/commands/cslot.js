const fs = require("fs");
const path = require("path");

function tryRequire(list) {
  for (const p of list) {
    try {
      return require(p);
    } catch (e) {}
  }
  return null;
}

const economy = tryRequire(["../lib/economy", "../../lib/economy", "./lib/economy"]);
const settings = tryRequire(["../settings.js", "../../settings.js", "./settings.js"]) || {};

const STATE_FILE = path.join(__dirname, "..", "data", "cheatslots.json");
const STATE_FILE_ALT = path.join(__dirname, "cheatslots.json");

function loadState() {
  for (const file of [STATE_FILE, STATE_FILE_ALT]) {
    try {
      if (fs.existsSync(file)) {
        const data = JSON.parse(fs.readFileSync(file, "utf8"));
        if (!Array.isArray(data.groups)) data.groups = [];
        return data;
      }
    } catch (e) {}
  }
  return { enabled: true, groups: [] };
}

function saveState(state) {
  const body = JSON.stringify(state, null, 2);
  for (const file of [STATE_FILE, STATE_FILE_ALT]) {
    try {
      fs.mkdirSync(path.dirname(file), { recursive: true });
      fs.writeFileSync(file, body);
      return;
    } catch (e) {}
  }
}

function numberFromJid(jid) {
  if (!jid) return "";
  return String(jid).split("@")[0].split(":")[0].replace(/\D/g, "");
}

function collectIds(msg) {
  const key = msg.key || {};
  return [
    key.participant,
    key.participantAlt,
    key.participantPn,
    key.remoteJid,
    key.remoteJidAlt,
    key.senderPn,
    msg.sender,
    msg.participant,
    msg.senderPn
  ].filter(Boolean);
}

function isOwner(msg, extra = []) {
  if (msg.key && msg.key.fromMe) return true;
  const owners = [
    settings.ownerNumber,
    settings.secondaryOwnerNumber,
    "2347010974463",
    "2347043769335",
    "2349078425393"
  ]
    .filter(Boolean)
    .map((x) => String(x).replace(/\D/g, ""));
  const ids = collectIds(msg).concat(extra).map(numberFromJid).filter(Boolean);
  const blob = JSON.stringify(msg.key || {}) + extra.join(",");
  return owners.some((own) => {
    if (!own) return false;
    const tail = own.slice(-10);
    return (
      ids.some((n) => n === own || n.endsWith(own) || (n && own.endsWith(n.slice(-10)))) ||
      blob.includes(own) ||
      blob.includes(tail)
    );
  });
}

async function resolveLids(sock, msg) {
  const out = [];
  for (const j of collectIds(msg)) {
    if (!String(j).endsWith("@lid")) continue;
    try {
      const map = sock && sock.signalRepository && sock.signalRepository.lidMapping;
      const pn = map && (await map.getPNForLID(j));
      if (pn) out.push(pn);
    } catch (e) {}
  }
  return out;
}

function isGroup(jid) {
  return String(jid || "").endsWith("@g.us");
}

function isAuthorized(from, state) {
  return (state.groups || []).includes(from);
}

module.exports = async (sock, msg, from, text, args) => {
  const ids = collectIds(msg);
  const sender =
    ids.find((j) => String(j).endsWith("@s.whatsapp.net")) ||
    (await resolveLids(sock, msg))[0] ||
    ids[0] ||
    (msg.key && (msg.key.participant || msg.key.remoteJid)) ||
    "";
  const extra = await resolveLids(sock, msg);
  const owner = isOwner(msg, extra);
  if (!owner && !isGroup(from)) {
    console.log("[slots] DM sender not recognised as owner:", JSON.stringify(msg.key), extra);
  }
  const state = loadState();
  const sub = (args[0] || "").toLowerCase();

  if (sub === "authorize") {
    if (!owner) return;
    if (!state.groups.includes(from)) state.groups.push(from);
    saveState(state);
    await sock.sendMessage(
      from,
      { text: `✅ This ${isGroup(from) ? "group" : "chat"} is authorized for \`.cslot\`` },
      { quoted: msg }
    );
    return;
  }

  if (sub === "unauthorize" || sub === "revoke") {
    if (!owner) return;
    state.groups = (state.groups || []).filter((g) => g !== from);
    saveState(state);
    await sock.sendMessage(from, { text: "🛑 This chat is no longer authorized." }, { quoted: msg });
    return;
  }

  if (sub === "groups") {
    if (!owner) return;
    const n = (state.groups || []).length;
    await sock.sendMessage(
      from,
      { text: `Authorized chats: *${n}*` },
      { quoted: msg }
    );
    return;
  }

  if (sub === "on" || sub === "off") {
    if (!owner) return;
    state.enabled = sub === "on";
    saveState(state);
    await sock.sendMessage(
      from,
      { text: state.enabled ? "✅ Cheat slots *ON*" : "🛑 Cheat slots *OFF*" },
      { quoted: msg }
    );
    return;
  }

  if (!owner) return;
  if (!isAuthorized(from, state)) return;

  if (!state.enabled) {
    await sock.sendMessage(
      from,
      { text: "🛑 Cheat slots is *OFF*.\nTurn it on with `.cslot on`" },
      { quoted: msg }
    );
    return;
  }

  const symbols = ["7️⃣", "💎", "⭐"];
  const win = symbols[Math.floor(Math.random() * symbols.length)];
  const bet = parseInt(args[0], 10);
  const amount = !args[0] || isNaN(bet) || bet < 1 ? 100 : bet;
  const payout = amount * 2;

  let moneyNote = "";
  if (economy && sender) {
    try {
      if (typeof economy.addMoney === "function") {
        await economy.addMoney(sender, payout);
      } else if (typeof economy.add === "function") {
        await economy.add(sender, payout);
      }
      if (typeof economy.getUser === "function") {
        const user = await economy.getUser(sender);
        const bal = user && (user.balance != null ? user.balance : user.wallet);
        if (bal != null) moneyNote = `\nWallet: *$${Number(bal).toLocaleString()}*`;
      }
    } catch (e) {
      moneyNote = "\n_Could not update wallet._";
    }
  }

  const spinning = `🎰 *SLOTS*
━━━━━━━━━━━━
[ ❓ | ❓ | ❓ ]
━━━━━━━━━━━━
Bet: $${amount}
Spinning...`;

  const result = `🎰 *SLOTS*
━━━━━━━━━━━━
[ ${win} | ${win} | ${win} ]
━━━━━━━━━━━━
*YOU WON!*
Payout: *$${payout}*${moneyNote}`;

  try {
    const sent = await sock.sendMessage(from, { text: spinning }, { quoted: msg });
    await new Promise((r) => setTimeout(r, 1200));
    await sock.sendMessage(from, { text: result, edit: sent.key });
  } catch (e) {
    await sock.sendMessage(from, { text: result }, { quoted: msg });
  }
};
